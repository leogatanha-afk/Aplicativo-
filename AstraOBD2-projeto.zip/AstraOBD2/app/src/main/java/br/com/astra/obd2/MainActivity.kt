package br.com.astra.obd2

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private var socket: BluetoothSocket? = null
    private lateinit var status: TextView
    private lateinit var values: TextView
    private lateinit var log: TextView
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        status = TextView(this).apply { text = "Astra OBD2 • Desconectado"; textSize = 20f }
        val connect = Button(this).apply { text = "Conectar Bluetooth" }
        val refresh = Button(this).apply { text = "Atualizar dados" }
        val dtc = Button(this).apply { text = "Ler códigos de falha" }
        values = TextView(this).apply { textSize = 18f; text = "RPM: --\\nVelocidade: -- km/h\\nTemperatura: -- °C\\nCarga do motor: -- %" }
        log = TextView(this).apply { textSize = 13f }
        root.addView(status); root.addView(connect); root.addView(refresh); root.addView(dtc); root.addView(values); root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
        connect.setOnClickListener { connectBluetooth() }
        refresh.setOnClickListener { readLive() }
        dtc.setOnClickListener { runCommand("03") { log.text = "Resposta DTC (Modo 03): $it" } }
    }

    private fun connectBluetooth() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 10); return
        }
        val bt = adapter
        if (bt == null) { status.text = "Bluetooth indisponível"; return }
        if (!bt.isEnabled) { status.text = "Ative o Bluetooth do celular"; return }
        try {
            val device = bt.bondedDevices.firstOrNull { (it.name ?: "").contains("OBD", true) || (it.name ?: "").contains("ELM", true) }
            if (device == null) { status.text = "Pareie o ELM327 nas configurações Bluetooth primeiro"; return }
            status.text = "Conectando a ${device.name}..."
            thread {
                try {
                    val s = device.createRfcommSocketToServiceRecord(spp)
                    s.connect(); socket = s
                    listOf("ATZ","ATE0","ATL0","ATS0","ATH0","ATSP0").forEach { send(it); Thread.sleep(300); readResponse(500) }
                    runOnUiThread { status.text = "Conectado: ${device.name}" }
                } catch (e: Exception) { runOnUiThread { status.text = "Falha na conexão: ${e.message}" } }
            }
        } catch (_: SecurityException) { status.text = "Permissão Bluetooth necessária" }
    }

    private fun send(cmd: String) { socket?.outputStream?.write((cmd + "\r").toByteArray()); socket?.outputStream?.flush() }
    private fun readResponse(timeout: Long = 1200): String {
        val s = socket ?: return ""
        val input = s.inputStream
        val out = StringBuilder()
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeout) {
            while (input.available() > 0) {
                val c = input.read()
                if (c >= 0 && c.toChar() != '>') out.append(c.toChar())
            }
            Thread.sleep(20)
        }
        return out.toString().replace("\r"," ").trim()
    }
    private fun runCommand(cmd: String, callback: (String)->Unit) {
        if (socket?.isConnected != true) { status.text = "Conecte o adaptador primeiro"; return }
        thread {
            try { send(cmd); val answer = readResponse(); runOnUiThread { callback(answer.ifBlank { "Sem resposta" }) } }
            catch (e: Exception) { runOnUiThread { status.text = "Erro OBD: ${e.message}" } }
        }
    }
    private fun readPid(cmd: String, prefix: String): String {
        send(cmd)
        val raw = readResponse().replace(" ","").uppercase()
        val pos = raw.indexOf(prefix)
        return if (pos >= 0 && raw.length >= pos + prefix.length + 2) raw.substring(pos + prefix.length, pos + prefix.length + 2) else "--"
    }
    private fun readLive() {
        if (socket?.isConnected != true) { status.text = "Conecte o adaptador primeiro"; return }
        thread {
            try {
                val rpmBytes = readPid("010C","410C")
                val rpm = rpmBytes.toIntOrNull(16)?.let { (it / 4).toString() } ?: "--"
                val speed = readPid("010D","410D").toIntOrNull(16)?.toString() ?: "--"
                val temp = readPid("0105","4105").toIntOrNull(16)?.minus(40)?.toString() ?: "--"
                val load = readPid("0104","4104").toIntOrNull(16)?.let { (it * 100 / 255).toString() } ?: "--"
                runOnUiThread { values.text = "RPM: $rpm\\nVelocidade: $speed km/h\\nTemperatura: $temp °C\\nCarga do motor: $load %" }
            } catch (e: Exception) { runOnUiThread { status.text = "Erro na leitura: ${e.message}" } }
        }
    }
    override fun onDestroy() { try { socket?.close() } catch (_: Exception) {}; super.onDestroy() }
}
